﻿namespace ShoppingApplication.Exceptions
{
    public class NoRecords
    {
    }
}
