﻿namespace ShoppingApplication.Models.DTOs
{
    public class CartsDTO
    {
        public int CartId { get; set; }
        public int ProductId { get; set; }
        public int ProductQuntity { get; set; }
        public string UserName { get; set; }
    }
}
